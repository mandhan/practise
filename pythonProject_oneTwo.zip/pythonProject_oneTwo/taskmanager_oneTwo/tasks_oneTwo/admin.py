

# Register your models here.
#
# from django.contrib import admin
# from django.contrib.auth.models import User  # Assuming you're using the built-in User model
#
# admin.site.register(User)
