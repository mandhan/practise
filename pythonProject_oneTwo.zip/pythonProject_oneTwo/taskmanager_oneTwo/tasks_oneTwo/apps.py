from django.apps import AppConfig


class TasksOnetwoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tasks_oneTwo'
