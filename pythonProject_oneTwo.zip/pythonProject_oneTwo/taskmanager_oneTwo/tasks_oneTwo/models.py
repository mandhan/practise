# Create your models here.
from django.db import models
from django.contrib.auth.models import User


#
# class Task(models.Model):
#     # objects = None
#
#     title = models.CharField(max_length=200)
#     description = models.TextField()
#     due_date = models.DateField()
#     created_by = models.ForeignKey(User, on_delete=models.CASCADE)
#
#     objects = models.Manager()


class Task(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    due_date = models.DateField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)  # Link to User model

    objects = models.Manager()  # Default manager for querying objects

    # Optionally define custom methods for your model
    def __str__(self):
        return self.title  # Return a string representation for display purposes

    # .. other model methods, if needed
